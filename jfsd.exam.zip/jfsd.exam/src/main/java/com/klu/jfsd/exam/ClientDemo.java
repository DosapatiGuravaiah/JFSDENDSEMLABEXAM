package com.klu.jfsd.exam;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class ClientDemo {
    public static void main(String[] args) {
        // Step 1: Configure Hibernate
        Configuration cfg = new Configuration();
        cfg.configure("hibernate.cfg.xml");
        cfg.addAnnotatedClass(Customer.class);

        SessionFactory sessionFactory = cfg.buildSessionFactory();

        // Insert Records
        insertRecords(sessionFactory);

        // Retrieve and Print All Records
        fetchAllRecords(sessionFactory);

        sessionFactory.close();
    }

    private static void insertRecords(SessionFactory sessionFactory) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();

            Customer c1 = new Customer();
            c1.setName("abc");
            c1.setEmail("abc.abc@example.com");
            c1.setAge(28);
            c1.setLocation("New");

            Customer c2 = new Customer();
            c2.setName("aaa");
            c2.setEmail("aa@gmail.com");
            c2.setAge(32);
            c2.setLocation("loi");

            session.persist(c1);
            session.persist(c2);

            tx.commit();
        }
    }

    private static void fetchAllRecords(SessionFactory sessionFactory) {
        try (Session session = sessionFactory.openSession()) {
            List<Customer> customers = session.createQuery("from Customer", Customer.class).list();

            System.out.println("=== All Customers ===");
            for (Customer customer : customers) {
                System.out.println("ID: " + customer.getId() +
                                   ", Name: " + customer.getName() +
                                   ", Email: " + customer.getEmail() +
                                   ", Age: " + customer.getAge() +
                                   ", Location: " + customer.getLocation());
            }
        }
    }
}
